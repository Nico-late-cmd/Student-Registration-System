/* ==========================================================================
   Online Exam Registration System — prototype logic
   Accounts + sessions are simulated with localStorage (Module 5 will
   replace every TODO with a fetch() to a PHP/MySQL endpoint).
   ========================================================================== */

const OERS = (() => {

  const EXAMS = [
    { id: "EX-101", code: "IBL 2305", title: "Software Design and Development", date: "2026-08-14", time: "9:00 AM", venue: "Hall A - Main Campus", fee: 1500, capacity: 120, registered: 87 },
    { id: "EX-102", code: "ICS 2204", title: "Database Systems II", date: "2026-08-15", time: "2:00 PM", venue: "Hall B - Main Campus", fee: 1200, capacity: 90, registered: 90 },
    { id: "EX-103", code: "IIT 2301", title: "Computer Networks", date: "2026-08-18", time: "9:00 AM", venue: "ICT Block Lab 3", fee: 1200, capacity: 60, registered: 41 },
    { id: "EX-104", code: "IBL 2210", title: "Systems Analysis and Design", date: "2026-08-19", time: "11:00 AM", venue: "Hall A - Main Campus", fee: 1500, capacity: 100, registered: 58 },
  ];

  const DEMO_ACCOUNT = { regNumber: "SCCJ/03158/2024", password: "Student@123", email: "demo.student@tuk.ac.ke" };

  function seed() {
    if (!localStorage.getItem("oers_exams")) localStorage.setItem("oers_exams", JSON.stringify(EXAMS));
    if (!localStorage.getItem("oers_accounts")) localStorage.setItem("oers_accounts", JSON.stringify([DEMO_ACCOUNT]));
  }

  function getExams() { seed(); return JSON.parse(localStorage.getItem("oers_exams")); }
  function getExamById(id) { return getExams().find(e => e.id === id); }
  function getAccounts() { seed(); return JSON.parse(localStorage.getItem("oers_accounts")); }

  function createAccount(regNumber, email, password) {
    const accounts = getAccounts();
    if (accounts.find(a => a.regNumber.toUpperCase() === regNumber.toUpperCase())) {
      return { ok: false, error: "An account with this registration number already exists." };
    }
    accounts.push({ regNumber, email, password });
    localStorage.setItem("oers_accounts", JSON.stringify(accounts));
    return { ok: true };
  }

  function findAccount(regNumber) {
    return getAccounts().find(a => a.regNumber.toUpperCase() === regNumber.toUpperCase());
  }

  function login(regNumber, password) {
    const acct = findAccount(regNumber);
    if (!acct) return { ok: false, error: "No account found for this registration number." };
    if (acct.password !== password) return { ok: false, error: "Incorrect password." };
    sessionStorage.setItem("oers_user", JSON.stringify({
      name: acct.regNumber, regNumber: acct.regNumber, initials: acct.regNumber.slice(0, 2).toUpperCase()
    }));
    return { ok: true };
  }

  function resetPassword(regNumber, newPassword) {
    const accounts = getAccounts();
    const acct = accounts.find(a => a.regNumber.toUpperCase() === regNumber.toUpperCase());
    if (!acct) return { ok: false, error: "No account found for this registration number." };
    acct.password = newPassword;
    localStorage.setItem("oers_accounts", JSON.stringify(accounts));
    return { ok: true };
  }

  function currentUser() {
    const raw = sessionStorage.getItem("oers_user");
    return raw ? JSON.parse(raw) : null;
  }

  function requireAuth(redirectTo = "index.html") {
    if (!currentUser()) window.location.href = redirectTo;
  }

  function logout() {
    sessionStorage.removeItem("oers_user");
    window.location.href = "index.html";
  }

  function setPendingExam(examId) { sessionStorage.setItem("oers_pending_exam", examId); }
  function getPendingExam() {
    const id = sessionStorage.getItem("oers_pending_exam");
    return id ? getExamById(id) : null;
  }

  function confirmRegistration(examId, method) {
    const exams = getExams();
    const exam = exams.find(e => e.id === examId);
    if (!exam) return null;
    exam.registered += 1;

    const registration = {
      slipNumber: "OERS-" + Date.now().toString().slice(-8),
      examId: exam.id, examTitle: exam.title, examCode: exam.code,
      date: exam.date, time: exam.time, venue: exam.venue, fee: exam.fee,
      method, student: currentUser(), issuedAt: new Date().toISOString(),
    };

    localStorage.setItem("oers_exams", JSON.stringify(exams));

    const key = "oers_registrations";
    const all = JSON.parse(localStorage.getItem(key) || "[]");
    all.push(registration);
    localStorage.setItem(key, JSON.stringify(all));
    sessionStorage.setItem("oers_last_registration", JSON.stringify(registration));
    return registration;
  }

  function getLastRegistration() {
    const raw = sessionStorage.getItem("oers_last_registration");
    return raw ? JSON.parse(raw) : null;
  }

  function getMyRegistrations() {
    const user = currentUser();
    if (!user) return [];
    const all = JSON.parse(localStorage.getItem("oers_registrations") || "[]");
    return all.filter(r => r.student && r.student.regNumber === user.regNumber);
  }

  function toast(msg) {
    let el = document.querySelector(".toast");
    if (!el) { el = document.createElement("div"); el.className = "toast"; document.body.appendChild(el); }
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove("show"), 2600);
  }

  function renderTopbarUser() {
    const user = currentUser();
    const slot = document.querySelector("[data-user-chip]");
    if (slot && user) {
      slot.innerHTML = `
        <div class="user-chip">
          <div class="meta"><b>${user.name}</b>Student</div>
          <div class="avatar">${user.initials}</div>
        </div>
      `;
    }
  }

  function wirePasswordToggles() {
    document.querySelectorAll(".toggle-eye").forEach(icon => {
      icon.addEventListener("click", () => {
        const input = icon.parentElement.querySelector("input");
        if (!input) return;
        const isPw = input.type === "password";
        input.type = isPw ? "text" : "password";
        icon.classList.toggle("fa-eye", !isPw);
        icon.classList.toggle("fa-eye-slash", isPw);
      });
    });
  }

  function wireLogout() {
    document.querySelectorAll("[data-logout]").forEach(btn => btn.addEventListener("click", logout));
  }

  return {
    getExams, getExamById, createAccount, login, resetPassword, findAccount,
    currentUser, requireAuth, logout, setPendingExam, getPendingExam,
    confirmRegistration, getLastRegistration, getMyRegistrations,
    toast, renderTopbarUser, wirePasswordToggles, wireLogout,
  };
})();
