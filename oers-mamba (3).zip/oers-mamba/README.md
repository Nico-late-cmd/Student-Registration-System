# Online Exam Registration System — Frontend Prototype
### (Mamba University visual theme, adapted to the exam-registration domain)

Frontend boilerplate for **IBL 2305: Software Design and Development**
(Module 4 — UI/UX Prototyping), Meet 3 deliverable.

This reuses the **exact color palette, typography, and sidebar-based layout
system** from the Mamba University Student Registration System reference
project, but every page's content and flow has been rebuilt around
**exam registration** (not course/unit registration).

## Pages

| File | Purpose |
|---|---|
| `index.html` | Sign In / Create Account / Forgot Password (one page, 3 views) |
| `dashboard.html` | Stat cards (exams available, my registrations, fees paid, next exam), quick actions, recent activity |
| `exams.html` | Browse exams you're eligible for, with seat/eligibility pills |
| `register.html` | 3-step registration: select exam → pay → admission slip |
| `slip.html` | Generated admission slip (angular boarding-pass stub, printable) |
| `admin.html` | Admin view: exam schedule table + registration/revenue stats |

## Design system (carried over from Mamba University)

- **Colors:** dusk-olive (`#1e2420`) + venom-lime (`#8fae3f`) on savanna-sand
  surfaces (`#f1ecdd`); teal for confirmed/paid, rust for full/rejected,
  dune for pending
- **Type:** Oswald (headings) · Inter (body) · IBM Plex Mono (registration
  numbers, exam codes, money, slip numbers)
- **Icons:** Font Awesome 6 via CDN
- **Layout:** sidebar (desktop) → icon rail (tablet) → horizontal scroll bar
  (mobile), same breakpoints as the reference project (1024px / 860px / 700px / 520px)
- **Signature element:** the admission slip is an angular ticket stub with a
  diagonal zig-zag cut between panels (no rounded corners / circular
  perforation, matching the theme's "sharp geometry" direction)
- All tokens are CSS custom properties in `:root` at the top of `style.css`

## Accounts & sessions (prototype, no backend yet)

`js/app.js` simulates accounts and sessions with `localStorage`/`sessionStorage`:

- Only registered accounts can sign in (unregistered reg. numbers are rejected).
- **Create Account** is a view inside `index.html`.
- **Forgot Password** verifies the registration number, then sets a new password directly.
- **Remember me** stores the registration number in the browser.
- Password fields have a show/hide eye icon.
- Protected pages (`dashboard.html`, `exams.html`, `register.html`, `slip.html`,
  `admin.html`) redirect to `index.html` if there's no active session.

Demo account (seeded automatically):

```
Registration Number: SCCJ/03158/2024
Password:            Student@123
```

## Running it locally

No build step — open `index.html` directly, or serve the folder:

```bash
python3 -m http.server 8000
```

## Connecting to PHP & MySQL (Module 5)

- `js/app.js → login()` / `createAccount()` / `resetPassword()` — replace
  with `fetch()` calls to `api/login.php`, `api/register.php`,
  `api/reset_password.php`.
- `js/app.js → confirmRegistration()` — POST to `api/register_exam.php`,
  which should check seat capacity and eligibility server-side (see
  Module 1 SRS, FR-04 and FR-05).
- `js/app.js → getExams()` — replace the hard-coded `EXAMS` array with a
  `fetch('api/exams.php')` call reading from the `Exam`/`Course` tables in
  the ERD.
- `admin.html`'s "+ Add exam" button is a placeholder for
  `api/schedule_exam.php`.

## Git

```bash
git init
git add .
git commit -m "Initial commit: Exam Registration System frontend boilerplate (Mamba theme)"
git remote add origin <your-repo-url>
git branch -M main
git push -u origin main
```
